
<template>
  <div>
      <navigation></navigation>
    

  

  </div>
</template>

<script>
import navigation from './Homecomponents/navigation.vue';

export default {
  name: 'home',
  components:{
      'navigation':navigation
  },
  data () {
    return {
      msg: 'Welcome to Login'
    }
  }
}
</script>

<style scoped>
body{
    background-color: #e6ecf0!important; 
}
</style>