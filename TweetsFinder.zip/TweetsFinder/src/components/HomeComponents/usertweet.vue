
<template>
  <div class="font-design">
    <div class="container">
      <div class="row modal-design">
        <div class="col-sm-6"></div>
        <div class="col-sm-6 col-sm-pull-1">   
          <span class="pull-right" data-toggle="modal" data-target="#postModal">Compose
          <i class="far fa-edit " ></i></span>
          <div id="postModal" class="modal fade" role="dialog">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header" >
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <p class="modal-title" > What's happening?</p>
                </div>
                <div class="modal-body">
                  <div class="form-group">
                      <textarea class="form-control" rows="5" v-model="tweetMessage"></textarea>
                  </div>
                  <div class="row ">
                    <div class="col-sm-12 text-right md-button-design">
                      <button class="btn btn-default" v-on:click ="postTweet" data-dismiss="modal">Post</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="row">
          <div class="col-sm-12">
            <h2 v-bind:class="{design:design}">{{text}}</h2>
          </div>  
          <div class="col-sm-6 col-md-5 col-md-push-1" v-for="tweetdatas in tweetdata" :key="tweetdatas.id">
            <div class="panel panel-default">
              <div class="panel-body">
                <div class="row">
                  <div class="col-xs-1 col-sm-2">
                    <img class="img-circle user-img" :src="tweetdatas.user.profile_image_url_https" >
                  </div>
                  <div class="col-xs-11 col-sm-10">
                    <div class="row">
                      <div class="col-sm-12">
                        <span>{{tweetdatas.user.screen_name}}</span>
                        <span><a v-bind:href="tweetdatas.link">@{{tweetdatas.user.name}}</a></span>
                      </div>
                      <div class="col-sm-12 following-tweets">
                        <p>{{tweetdatas.text}}</p>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-xs-11 col-xs-push-1 col-sm-10 col-sm-push-2 count">
                    <ul style="padding:0px;">
                      <li style="display:inline-block;"><i class="fas fa-retweet"></i> {{tweetdatas.retweet_count}}</li>
                      <li style="display:inline-block;"><i class="far fa-heart"></i>{{tweetdatas.favorite_count}}</li>
                    </ul>
                  </div>
                </div>
                <div class="row text-center user-info">
                  <div class="col-xs-3 col-sm-3">
                    <p>Tweets</p>
                    <p>{{tweetdatas.user.statuses_count}}</p>
                  </div>
                  <div class="col-xs-3 col-sm-3">
                    <p>Following</p>
                    <p>{{tweetdatas.user.friends_count}}</p>
                  </div>
                  <div class="col-xs-3 col-sm-3">
                    <p>Followers</p>
                    <p>{{tweetdatas.user.followers_count}}</p>
                  </div>
                  <div class="col-xs-3 col-sm-3">
                   <p>Likes</p>
                  <p>{{tweetdatas.user.favourites_count}}</p>
                  </div>
                </div>
              </div>
            </div>
         </div>
      </div>
    </div>
  </div>
</template>

<script>
import cb from '../Homecomponents/lib/twitterapi.js';
let results;

export default {
 name: 'usertweet',
  data () {
    return {
    tweetMessage:"",
    tweetdata:[],
    design:true,
    text:"Loading..."
     }
  },
  created(){
    results = this;
    results.fetchTweet();
  },
  methods:{
    postTweet:function(){
      if(results.tweetMessage !=""){
      var params = {status: results.tweetMessage};
      console.log(params);
      cb.__call(
      "statuses_update",
      params,
      function (reply, rate, err) {
       results.fetchTweet();
       alert("Successfully Post");
      });
      }
      else{
        alert("Empty Input");
      }
      console.log(results.tweetMessage);
    
    
     },
    fetchTweet: function(){ 
     cb.__call(
      "statuses_homeTimeline",
      {},
    function(reply, rate, err) {
      results.tweetdata = reply;
      console.log(reply);
      results.design =  false;
      results.text =""; 
       for(let tweetdatas of results.tweetdata){   
            tweetdatas.link = 'https://mobile.twitter.com/'+  tweetdatas.user.screen_name;
        } 
      } );
    }
  }
}
</script>

<style scoped>
.font-design{
     font-family: 'PT Sans', sans-serif;
}
.following-tweets{
 white-space: wrap; 
    overflow: hidden;
    text-overflow: ellipsis;
    height: 50px;
  margin: 10px auto;
}
.panel-body{
  padding-bottom: 0px;
}
.user-info{
    background-color: #f2f2f2;
    padding: 7px 0px;
}
.user-info p:first-child{
margin: 0px;
    font-size: 12px;
    letter-spacing: 0.5px;
    font-weight: 500;
}
.user-info p:last-child{
font-weight: 700;
    font-size: 21px;
    margin: 0px;
}

.count ul{
  margin-bottom: 20px;
}
.count li{
margin-right: 10px;

}
.count li i{
margin-right: 3px;

}
.design{
    font-size: 40px;
    text-align: center;
    margin: 100px 0px;
    font-style: italic;
    font-weight: 300;
}
.modal-design{
padding: 20px 0px;
}
.modal-header {
padding:10px 15px;
}
.modal-header p{
font-size:15px;font-style:italic;
}
.md-button-design .btn{
background-color: #4AB3F4;
font-weight: 700;
font-size: 13px;
padding: 6px 29px;
color: #fff;
border-radius: 20px;
letter-spacing: .7px;
}
.panel-default{
box-shadow: rgba(0, 0, 0, 0.1) 0px 5px 10px 0px;
}
.user-img{
border: 2px solid #fff;
}


</style>