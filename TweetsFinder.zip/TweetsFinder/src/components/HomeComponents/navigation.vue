
<template>
  <div>
    <div class="container-fluid nav-bg">
      <div class="container">
        <nav class="navbar navbar-default" >
          <div class="container-fluid">
            <div class="navbar-header" style="">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span> 
              </button>
              <span style="">Tweets <i class="fab fa-twitter"></i> Finder</span>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
              <ul class="nav navbar-nav navbar-right" >
                <li v-on:click = "component = 'usertweet', profactive()" v-bind:class="{tweetdesign:tweetdesign, design:profactives}">Home </li>
                <li v-on:click = "component = 'searchtweet',tweetsactive()" v-bind:class="{tweetdesign:tweetdesign , design:tweetsactives}">Search Tweets</li>
                <li class="dropdown">
                  <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                    <span class="caret"></span>
                  </a>
                  <ul class="dropdown-menu">
                    <li>
                      <router-link to="/">Log out   </router-link>
                   
                    </li> 
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </div>
    </div> 

    <component v-bind:is = "component" ></component>
  </div>
</template>

<script>
import searchtweet from './searchtweet.vue';
import usertweet from './usertweet.vue';
export default {
  name: 'navigation',
      components:{
          'searchtweet':searchtweet,
          'usertweet':usertweet

    },
  data () {
    return {
     component:'usertweet',
     profactives:true,
     tweetsactives:false,
     tweetdesign:true
    }
  },
  methods:{
      profactive:function(){
        this.profactives = true;
        this.tweetsactives =false;
      },
      tweetsactive:function(){
this.profactives = false;
        this.tweetsactives = true;
      }
  }
}
</script>

<style scoped>
.navbar{
  margin:0px;
}
.tweetdesign{
  padding:15px;
  cursor: pointer;
}
.navbar-default{
padding:0px; background-color: #54b9ed;border-color:transparent;
}
.navbar-default .navbar-nav>li>a {
    color: #FFF}
.bg-info{
       background-color: #54b9ed;
}
.navbar-expand-md .navbar-nav .nav-link {
 
    text-decoration: none;
    color: white;
}
.nav-bg{
padding:0px; background-color: #54b9ed
}
.navbar-header{
padding:12px;
}
.navbar-header span{
font-family: 'Pacifico', cursive;
font-size:18px;
}
.nav .navbar-nav .navbar-right{
font-family: 'PT Sans', sans-serif;
}
.caret{
  color:#333;
}
.design{
  border-bottom: 3px solid #fff;
    margin-bottom: -2px;
    color: #fff;
}
.navbar-default .navbar-nav>li>a:active{
  background-color: transparent;
}
@media only screen and (max-width: 767px) {
.navbar-header{
  padding: 0px;
}
.navbar-header span{
  line-height: 3;
}
.navbar-default .navbar-toggle{
  border:none;
}
.navbar-default .navbar-toggle .icon-bar{
  background-color: #333;
}
.navbar-default .navbar-toggle:focus, .navbar-default .navbar-toggle:hover{
  background-color: transparent;
}
.design{
  border-bottom:none;
}
}
</style>