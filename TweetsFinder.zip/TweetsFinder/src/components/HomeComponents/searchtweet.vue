<template>
  <div style="font-family: 'PT Sans', sans-serif;">
        <div class="container searchtweet" >
            <div class="row">
                <div class=" col-sm-8 hidden-xs text-left">
                  <p>{{seachresult}} Search Found.</p>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Search Tweets" v-on:change="searchTweets" v-model = "search">
                    </div>
                </div>
                <div class=" col-xs-12 visible-xs text-left">
                  <p>{{seachresult}} Search Found.</p>
                </div>
                <div class="col-sm-12">
                     <h2 v-bind:class="{design:design}">{{text}}</h2>
                </div>    
            </div>
        </div>
        
        <div class="container" >
            <div class="row"  >   
                <div class="col-xs-12 col-sm-6 col-md-4 text-center" v-for="tweets in tweetsResult" :key="tweets.id"  >
                    <div class="panel panel-default">
                        <div class="panel-body" >
                         <div class="row banner" >
                            <img :src="tweets.user.profile_banner_url" class="img-responsive"/>
                         </div >
                        <div class="row" >
                            <div class="col-sm-3" >
                                <img class="img-circle"  width="75" height="75"  alt="img" :src="tweets.user.profile_image_url" style="border: 2px solid #fff"/>
                            </div>

                            <div class="username col-sm-9 text-left">
                            <p >{{tweets.user.name}} </p>
                            <p class="card-text"><a v-bind:href="tweets.link" target="_blank">{{tweets.user.screen_name}} </a></p>
                            </div>
                            <div  class=" col-sm-12 text-justify tweet-content">
                                <p>{{tweets.text}}</p>
                            </div>
                            <div class="row text-center user-info">
                                <div class="col-xs-3 col-sm-3">
                                    <p>Tweets</p>
                                    <p>{{tweets.user.statuses_count}}</p>
                                </div>
                                <div class="col-xs-3  col-sm-3">
                                    <p>Following</p>
                                    <p>{{tweets.user.friends_count}}</p>
                                </div>
                                <div class="col-xs-3  col-sm-3">
                                    <p>Followers</p>
                                    <p>{{tweets.user.followers_count}}</p>
                                </div>
                                <div class="col-xs-3  col-sm-3">
                                    <p>Likes</p>
                                    <p>{{tweets.user.favourites_count}}</p>
                                </div>
                            </div>
                        </div>   
                        </div>
                    </div>
                </div>    
            </div>
        </div>
  </div>
</template>

<script>
import cb from '../Homecomponents/lib/twitterapi.js';
let result;

export default {
  name: 'searchtweet',
  data () {
    return {
    msg: 'Welcome to Your Vue.js App',
      search:'',
      tweetsResult:[],
      seachresult: 0,
      text:"Lets start seaching",
      design:true
    }
  },
     created(){
    result = this;

  },
  methods:{
   searchTweets:function (){  
       result.text = "Loading...."
        cb.__call(
        "search_tweets",
    "q=" + this.search,
    function (data) {
         result.tweetsResult = data.statuses ;
        result.seachresult = result.tweetsResult.length;
        result.design = false;
        result.text = "";
         for( let tweets of result.tweetsResult){
            tweets.user.screen_name = '@' +  tweets.user.screen_name ;
            tweets.link = 'https://mobile.twitter.com/'+  tweets.user.screen_name;
        } 

   
    },
    true // this parameter required
);
    }
  }
}
</script>

<style scoped>

.searchtweet{
    margin: 30px auto;
}
.searchtweet p{
    margin:10px 0px 0px;
    font-size: 17px;font-weight: 600;font-style: italic;
}
.tweets-result{
    margin-bottom: 20px;
}
.username p{
color: #657786;
    font-size: 12px;
    font-weight: bold;
    letter-spacing: .02em;
}
.user-info p:first-child{
margin: 0px;
    font-size: 12px;
    letter-spacing: 0.5px;
    font-weight: 500;
}
.user-info p:last-child{
font-weight: 700;
    font-size: 14px;
    margin: 0px;
}
.design{
    font-size: 40px;
    text-align: center;
    margin: 66px 0px;
    font-style: italic;
    font-weight: 300;
}
.panel-body{
padding-top:0px;
}
.banner{
margin-bottom: -36px;
}
.banner img{
height: 94px ;width: 100%;
}
.username p:first-child{
margin:40px 0px 0px 0px;
}
.tweet-content{
height:100px; overflow: hidden;text-overflow:ellipsis;
}

@media only screen and (max-width: 767px) {
  .username p:first-child{
    margin:10px 0px 0px 0px;
}
}
</style>