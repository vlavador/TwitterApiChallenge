<template>
  <div class="login">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm- 12">
                <div class="panel panel-default">
                    <div class="panel-body" >
                        <div class="row">
                            <div class="col-sm-12 text-center header-panel">
                                <span> Tweets  <i class="fab fa-twitter"></i> Finder</span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-12 text-center">
                                <form role="form"> 
                                    <div class="form-group has-feedback">
                                        <input type="text" class="form-control" placeholder="Username" />
                                         <i class="form-control-feedback glyphicon glyphicon-user"></i>
                                     </div>
                                    <div class="form-group has-feedback">
                                        <input type="text" class="form-control" placeholder="Password" />
                                        <i class="form-control-feedback glyphicon glyphicon-lock"></i>
                                    </div>
                                    <router-link to="/home"> <button type="button" class="btn btn-default">Login</button></router-link>
                                </form>
                            </div>
                        
                        </div>
                        <div class="row panel-footers">
                            <div class="col-sm-12 text-center">
                                <span> <a href="#"> Sign up </a> </span> | <span> <a href="#"> Forgot account? </a> </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
</template>

<script>


export default {
  name: 'login',

  data () {
    return {
      msg: 'Welcome to Login'
    }
  }
}
</script>

<style scoped>
.login{
        font-family: 'PT Sans', sans-serif; 
}
.form-control-feedback{
left :12px;
}
.form-control {
    padding: 17px 44px;
    border-radius:20px;
   
}
.btn {
color: #fff;
    background-color: #333;
    border-color: #333;
}
.btn-default{
    padding: 6px 60px;
    border-radius: 20px;
    font-size: 14px;
    font-weight: 700;
    letter-spacing: 0.5px;
}
.panel-default{
width: 300px; height:375px;margin:90px auto;background-color:#8dd0f2;border-radius: 10px;
box-shadow:0 5px 10px 0px rgba(0, 0, 0, 0.1);border-color:#8dd0f2;
}
.header-panel{
font-family: 'Pacifico', cursive;
    font-size: 27px;
    padding: 17px 0px 50px;
}
.header-panel span{
border-bottom: 3px solid black;
padding: 0px 16px;
}

.panel-footers{
margin-top:40px;
}
.panel-footers a{
text-decoration: none;
color:#333;
}
.panel-footers a:hover{
    text-decoration: underline;
}

</style>
