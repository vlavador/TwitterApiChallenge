import login from './components/login.vue'
import home from './components/home.vue'
export default[
    {path:'/',component:login},
    {path:'/home',component:home}
]